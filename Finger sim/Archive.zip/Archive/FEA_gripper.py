import numpy as np
import matplotlib.pyplot as plt
from elastica import *


beams = []
ribs = []
beams_list = []


# Geometry of beams
class GripperSimulator(
    BaseSystemCollection, Constraints, Forcing, Damping, CallBacks, Connections
):
    pass

class Beam:
    def __init__(self, simulator, start, direction, length, n_elem):
        self.rod = CosseratRod.straight_rod(
            n_elem,
            start,
            direction,
            normal = np.array([0.0, 0.0, 1.0]),
            base_length = length,
            base_radius = 0.01,
            density = 1.25,
           # nu = 0.3,
            youngs_modulus = 1e7,


            # n_elem, 
            # start, 
            # direction, 
            # normal = np.array([0.0, 0.0, 1.0]), # [x,y,z]
            # length = length, 
            # radius = 0.01, 
            # rho = 1000, 
            # youngs_modulus = 1e6, 
            # shear_modulus = 1e6
        )
        simulator.append(self.rod)









def endpoints_to_vector_and_length(beam_array):
    start = beam_array[0]
    end = beam_array[1]
    direction = end - start
    length = np.linalg.norm(direction)
    direction = direction / length if length > 0 else np.zeros_like(direction)
    return start, direction, length


# def create_ribs(simulator, left_start, left_end, right_start, right_end, n_ribs=10):
#     for t in np.linspace(0, 1, n_ribs):
        
#         p_left  = left_start  + (t+1e-9) * (left_end  - left_start)
#         p_right = right_start + (1-t) * (right_end - right_start)
#         start, direction, length = endpoints_to_vector_and_length([p_left, p_right])
        
#         ribs.append(Beam(simulator, start, direction, length, n_elem=5))

def new_main_beam(simulator, beam_points, n_elem=20):
    start, direction, length = endpoints_to_vector_and_length(beam_points)
    print("Start:", start)
    return Beam(simulator, start, direction, length, n_elem)


#Simulation setup

gripper_sim = GripperSimulator()
simulator = gripper_sim
final_time = 1
dt = 1e-4
total_steps = int(final_time/dt)

x = 0.03
y = 0.0045

# Main beams
main_beam_left = [np.array([0, 0, 0]), np.array([0, 0.1, 0])]  # Start and end of left beam
main_beam_right = [np.array([0, 0.1, 0]), np.array([x, y, 0])]  # Start and end of right beam




#print(endpoints_to_vector_and_length(main_beam_left))

# new_main_beam()


# create_ribs(simulator, main_beam_left[0], main_beam_left[1], main_beam_right[0], main_beam_right[1], n_ribs=10)

beam = new_main_beam(simulator, main_beam_left)
beams.append(beam)
beam = new_main_beam(simulator, main_beam_right)
beams.append(beam)

for i, b in enumerate(beams):
    beams_list.append(beams[i])

for i, r in enumerate(ribs):
    beams_list.append(ribs[i])

print(beams_list)

start_force = np.array([0.0, 0.0, 0.0])         # [N]
end_force = np.array([0.0, 0.0, 0.0])           # [N]



gripper_sim.connect(beams[0].rod, beams[1].rod, first_connect_idx=-1, second_connect_idx=0).using(
    HingeJoint,
    k=1e5,
    nu=1e2,
    kt=1e5,
    normal_direction=np.array([0.0, 0.0, 1.0]),
    # nut=1e2,
    # constrained_position_idx=(0,),
    # constrained_director_idx=(0,)    # początek prawej belki
)

gripper_sim.constrain(beams[0].rod).using(
    OneEndFixedBC,
    constrained_position_idx=(0,),
    constrained_director_idx=(0,)  #director not orientation!
)

gripper_sim.constrain(beams[1].rod).using(
    OneEndFixedBC,
    constrained_position_idx=(beams[1].rod.n_elems - 1,),
    constrained_director_idx=(beams[1].rod.n_elems - 1,)  #director not orientation!
)





gripper_sim.add_forcing_to(beams[0].rod).using(
    EndpointForces,
    start_force,
    end_force,
    ramp_up_time=0.1
)

gripper_sim.dampen(beams[0].rod).using(
    AnalyticalLinearDamper,
    damping_constant=0.1,
    time_step = dt
)
gripper_sim.finalize()

initial_positions = [beam.rod.position_collection.copy() for beam in beams_list]

timestepper = PositionVerlet()
integrate(timestepper, gripper_sim, final_time, total_steps)




final_positions = [beam.rod.position_collection for beam in beams_list]



# plt.figure(figsize=(10, 6))
# plt.xlabel('X [m]')
# plt.ylabel('Y [m]')
# plt.grid(True)

# # Rysowanie wszystkich belek i żeber
# for beam in beams_list:
#     pos = beam.rod.position_collection
#     plt.plot(pos[0], pos[1])

# plt.axis("equal")
# plt.title("All beams and ribs")
# plt.show()


plt.figure(figsize=(10, 6))
plt.xlabel('X [m]')
plt.ylabel('Y [m]')
plt.grid(True)

for pos in initial_positions:
    plt.plot(pos[0], pos[1], 'k--')
   # przed
plt.axis("equal")
plt.show()

for pos in final_positions:
    plt.plot(pos[0], pos[1], 'b-')  # po

# plt.legend(loc='upper left')
plt.axis("equal")
plt.title("Gripper deformation")
plt.show()

# initial_pos = beams_list[0].rod.position_collection.copy()


# final_pos = beams_list[0].rod.position_collection




# plt.figure(figsize=(10, 6))
# plt.xlabel('X [m]')
# plt.ylabel('Y [m]')
# plt.grid(True)

# plt.plot(final_pos[0], final_pos[1], label="after sim")
# plt.plot(initial_pos[0], initial_pos[1], label="before sim")

# plt.legend(loc='upper left')

# # Important: Keep aspect ratio equal so beams don't look stretched
# plt.axis("equal") 

# plt.title("Beam deflection")

# plt.show()


# """
# Notes of intern #2

# Fun stuff
# """





# new_beam = Beam(gripper_sim, start, direction, length)



# print("Start:", start)
# print("Direction:", direction)
# print("Length:", length)


# plt.plot([beam_left[0][0], beam_left[1][0]], [beam_left[0][1],beam_left[1][1]], 'k-', lw = 3) 
# plt.plot([beam_right[0][0], beam_right[1][0]], [beam_right[0][1],beam_right[1][1]], 'k-', lw = 3) 
# plt.plot(beam_right, beam_left, 'k-', lw = 3) 
  # Start and end of right beam
# Geometry of beams

# length = 1.0          # długość belek
# base_width = 0.4      # szerokość u podstawy (odległość między belkami)
# tip_width = 0.2      # szerokość na końcu (zbiegają się w trójkąt)
# n_ribs = 10           # liczba żeber

# --- Główne belki w kształcie trójkąta ---

# Lewa belka: od (0, 0) do (length, +tip_width/2)
# left_beam_x = np.array([0, length])
# left_beam_y = np.array([0, tip_width])

# # Prawa belka: od (0, base_width) do (length, -tip_width/2)
# right_beam_x = np.array([0, length])
# right_beam_y = np.array([base_width, tip_width])

# # Rysowanie belek
# # plt.plot(left_beam_x, left_beam_y, 'k-', lw=3, label="Lewa belka")
# # plt.plot(right_beam_x, right_beam_y, 'k-', lw=3, label="Prawa belka")

# # --- Żebra dopasowane do trójkąta ---

# rib_positions = np.linspace(0, length, n_ribs)

# for x in rib_positions:
#     t = x / length

#     # Punkt na lewej belce
#     x_left = left_beam_x[0] + t * (left_beam_x[1] - left_beam_x[0])
#     y_left = left_beam_y[0] + t * (left_beam_y[1] - left_beam_y[0])

#     # Punkt na prawej belce
#     x_right = right_beam_x[0] + t * (right_beam_x[1] - right_beam_x[0])
#     y_right = right_beam_y[0] + t * (right_beam_y[1] - right_beam_y[0])

#     # Rysowanie żebra
#     plt.plot([x_left, x_right], [y_left, y_right], 'b-', lw=2)

# Ustawienia wykresu



# plt.title("Fin-ray – belki ułożone w trójkąt (szkielet)")
# plt.xlabel("X [m]")
# plt.ylabel("Y [m]")
# plt.axis("equal")
# plt.grid(True)
# plt.legend()
# plt.show()
 