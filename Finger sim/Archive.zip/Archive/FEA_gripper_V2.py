import numpy as np
import elastica as ea

class GripperSimulator(
    ea.BaseSystemCollection, 
    ea.Constraints, 
    ea.Forcing, 
    ea.Damping, 
    ea.CallBacks, 
    ea.Connections
):
    pass

def endpoints_to_vector_and_length(beam_array):
    start = beam_array[0]
    end = beam_array[1]
    direction = end - start
    length = np.linalg.norm(direction)
    direction = direction / length if length > 0 else np.zeros_like(direction)
    return start, direction, length


gripper_sim = GripperSimulator()

n_elem = 10
# direction = np.array([0.0, 0.0, 1.0])
normal = np.array([0.0, 1.0, 0.0])
roll_direction = np.cross(direction, normal)
# base_length = 0.2
base_radius = 0.007
base_area = np.pi * base_radius**2
density = 1750
E = 3e7
poisson_ratio = 0.5
shear_modulus = E / (poisson_ratio + 1.0)

x = 0.03
y = 0.045


main_beam_left = [np.array([0, 0, 0]), np.array([0, 0.1, 0])]  # Start and end of left beam
main_beam_right = [np.array([0, 0.1, 0]), np.array([x, y, 0])]  # Start and end of right beam





# Creating main beams

main_beam_left = ea.CosseratRod.straight_rod(
    n_elem,
    main_beam_left[0],
    direction,
    normal,
    base_length,
    base_radius,
    density,
    youngs_modulus=E,
    shear_modulus=shear_modulus,
)

main_beam_right = ea.CosseratRod.straight_rod(
    n_elem,
    main_beam_right[0],
    direction,
    normal,
    base_length,
    base_radius,
    density,
    youngs_modulus=E,
    shear_modulus=shear_modulus,
)

"""Changing here direction and base length"""
