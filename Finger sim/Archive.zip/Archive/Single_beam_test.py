import numpy as np
from elastica import *
import matplotlib.pyplot as plt

#System definition
class GripperSimulator(
    BaseSystemCollection, Constraints, Forcing, Damping, CallBacks
):
    pass
"""
Notes of intern
BaseSystemCollection - allows to add beams
Constraints
Forcing - adding forces
Damping - preventing harmonic oscillations
CallBacks - allows to gather data during simulation. 
            Maybe i can delete this for final set of simulations? Cuz i will only gather bitmaps or sth..
            "Dopiero wywołanie collect_diagnostics(...).using(...) faktycznie zużywa zasoby. Lepiej mieć tę "furtkę" otwartą na wypadek, gdybyś nagle potrzebował sprawdzić wykres sił w konkretnym przegubie." ~ Gemini
"""

#Sim parametrs (everything is in metric system (N, Pa, m, s...))

class Beam:
    def __init__(self, simulator, start, end, n_elem): # n elements
        # material parameters
        E = 210000000       # Young's modulus Pa
        rho = 7800          # density g/m^3
        radius = 0.050      # round beams m
        nu = 0.3            # Poisson ratio
        G = E / (nu + 1.0)  # Kirchoff's modulus
        
        # Geometric calculations
        vector = end - start
        length = np.linalg.norm(vector)
        direction = vector / length
        
        # Orientation
        normal = np.array([0.0, 1.0, 0.0])
        if np.allclose(abs(direction), [0, 1, 0]):
            normal = np.array([1.0, 0.0, 0.0])
            
        # Rod creation
        self.rod = CosseratRod.straight_rod(
            n_elem, 
            start, 
            direction, 
            normal, 
            length, 
            radius, 
            rho, 
            youngs_modulus=E, 
            shear_modulus=G
        )
        simulator.append(self.rod)

# Simulation main setup
gripper_sim = GripperSimulator() #Creation of simulation world
final_time = 1
dt = 0.00001
total_steps = int(final_time/dt)


#adding beanz (by coordinate system)
beam_coordinates = [
    (np.array([0.0, 0.0, 0.0]), np.array([1.0, 0.0, 0.0])),  # Base

]

#(np.array([0.0, 0.0, 0.0]) - beggining
# , np.array([1.0, 0.0, 0.0])), - ending


# Creation of new beams based on coordinates
beams_list = []
for start, end in beam_coordinates:
    new_beam = Beam(gripper_sim, start, end, n_elem=15)
    beams_list.append(new_beam)


# Setting constraints

gripper_sim.constrain(beams_list[0].rod).using(
    OneEndFixedBC,
    constrained_position_idx=(0,),
    constrained_director_idx=(0,)  #director not orientation!
)


# SETTING FORCES

# Force vectors

start_force = np.array([0.0, 0.0, 0.0])         # [N]
end_force = np.array([0.0, 1000.0, 0.0])           # [N]


gripper_sim.add_forcing_to(beams_list[0].rod).using(
    EndpointForces,
    start_force,
    end_force,
    ramp_up_time=0.1
)

gripper_sim.dampen(beams_list[0].rod).using(
    AnalyticalLinearDamper,
    damping_constant=0.1,
    time_step = dt
)




# Finalize the system (mandatory before simulation or inspection)
gripper_sim.finalize()

initial_pos = beams_list[0].rod.position_collection.copy()








final_pos = beams_list[0].rod.position_collection


# for i, beam_obj in enumerate(beams_list):
#     positions = beam_obj.rod.position_collection
#     # Plotting X (index 0) and Y (index 1)
#     plt.plot(positions[0], positions[1], 'o-', label=f"Beam {i}", lw=2)


print(f"Simulation started. Quantity of steps: {total_steps}")

timestepper = PositionVerlet()
integrate(timestepper, gripper_sim, final_time, total_steps)

print(f"Simulation ended.")


plt.figure(figsize=(10, 6))
plt.xlabel('X [m]')
plt.ylabel('Y [m]')
plt.grid(True)

plt.plot(final_pos[0], final_pos[1], label="after sim")
plt.plot(initial_pos[0], initial_pos[1], label="before sim")

plt.legend(loc='upper left')

# Important: Keep aspect ratio equal so beams don't look stretched
plt.axis("equal") 

plt.title("Beam deflection")

plt.show()


"""
Notes of intern #2

Fun stuff
"""

