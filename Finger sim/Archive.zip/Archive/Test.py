import numpy as np
from elastica import *


class Beam:
    def __init__(self, simulator, start, direction, length, n_elem):
        self.rod = CosseratRod.straight_rod(
            n_elem,
            start,
            direction,
            np.array([0.0, 0.0, 1.0]),  # normal
            length,                     # base_length
            0.01,                       # base_radius
            1000,                       # density
            1e6                         # youngs_modulus
        )
        simulator.append(self.rod)
 



class GripperSimulator(
    BaseSystemCollection, Constraints, Forcing, Damping, CallBacks, Connections
):
    pass


def endpoints_to_vector_and_length(start, end):
    direction = end - start
    length = np.linalg.norm(direction)
    direction = direction / length
    return start, direction, length


def create_ribs(sim, left_rod, right_rod, n_ribs=10):
    ribs = []

    for i in range(1, n_ribs + 1):
        s = i / (n_ribs + 1)

        p_left = left_rod.position_collection[:, 0] * (1 - s) + left_rod.position_collection[:, -1] * s
        p_right = right_rod.position_collection[:, 0] * (1 - s) + right_rod.position_collection[:, -1] * s

        start, direction, length = endpoints_to_vector_and_length(p_left, p_right)

        rib = Beam(sim, start, direction, length, n_elem=3)
        ribs.append(rib.rod)

        # Połączenie z lewą belką
        sim.connect(
            first_rod=left_rod, first_connect_idx=int(s * left_rod.n_elems),
            second_rod=rib.rod, second_connect_idx=0
        ).using(FixedJoint)

        # Połączenie z prawą belką
        sim.connect(
            first_rod=right_rod, first_connect_idx=int(s * right_rod.n_elems),
            second_rod=rib.rod, second_connect_idx=rib.rod.n_elems
        ).using(FixedJoint)

    return ribs


# --- MAIN ---

sim = GripperSimulator()

# Główne belki
left_start = np.array([0, 0, 0])
left_end   = np.array([0, 0.1, 0])

right_start = np.array([0, 0.1, 0])
right_end   = np.array([0.03, 0.0045, 0])

start, direction, length = endpoints_to_vector_and_length(left_start, left_end)
left_beam = Beam(sim, start, direction, length, n_elem=20).rod

start, direction, length = endpoints_to_vector_and_length(right_start, right_end)
right_beam = Beam(sim, start, direction, length, n_elem=20).rod

# Mocowanie podstawy
sim.constrain(left_beam).using(OneEndFixedBC, constrained_position_idx=(0,))
sim.constrain(right_beam).using(OneEndFixedBC, constrained_position_idx=(0,))

# Żebra Fin Ray
ribs = create_ribs(sim, left_beam, right_beam, n_ribs=8)

# Tłumienie
sim.dampen(left_beam).using(AnalyticalLinearDamper, damping_constant=0.05)
sim.dampen(right_beam).using(AnalyticalLinearDamper, damping_constant=0.05)

# Finalizacja
sim.finalize()

# Integrator
timestepper = PositionVerlet()

dt = 1e-4
final_time = 1.0
steps = int(final_time / dt)

time = 0.0
for i in range(steps):
    timestepper.do_step(sim, time, dt)
    time += dt

print("Symulacja zakończona.")
