import numpy as np
import elastica as ea
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# ------------------------------------------------------------
# Geometry definition
# ------------------------------------------------------------
x = 0.03
y = 0.0045

main_beam_left = [np.array([0.0, 0.0, 0.0]), np.array([0.0, 0.1, 0.0])]
main_beam_right = [np.array([0.0, 0.1, 0.0]), np.array([x, y, 0.0])]

def endpoints_to_vector_and_length(beam_array):
    start = beam_array[0]
    end = beam_array[1]
    direction = end - start
    length = np.linalg.norm(direction)
    direction = direction / length if length > 0 else np.zeros_like(direction)
    return start, direction, length

# ------------------------------------------------------------
# Elastica system
# ------------------------------------------------------------
class BeamRibSimulator(
    ea.BaseSystemCollection,
    ea.Constraints,
    ea.Connections,
    ea.Forcing,
    ea.Damping,
    ea.CallBacks,
):
    pass

sim = BeamRibSimulator()

# ------------------------------------------------------------
# Material parameters
# ------------------------------------------------------------
n_elem_beam = 20
n_elem_rib = 5

radius = 0.003
density = 1750
E = 3e7
poisson_ratio = 0.5
shear_modulus = E / (poisson_ratio + 1.0)

normal_vec = np.array([0.0, 0.0, 1.0])

# ------------------------------------------------------------
# Create main beams
# ------------------------------------------------------------
start_L, dir_L, L_len = endpoints_to_vector_and_length(main_beam_left)
start_R, dir_R, R_len = endpoints_to_vector_and_length(main_beam_right)

beam_L = ea.CosseratRod.straight_rod(
    n_elem_beam, start_L, dir_L, normal_vec, L_len,
    radius, density, youngs_modulus=E, shear_modulus=shear_modulus
)
sim.append(beam_L)

beam_R = ea.CosseratRod.straight_rod(
    n_elem_beam, start_R, dir_R, normal_vec, R_len,
    radius, density, youngs_modulus=E, shear_modulus=shear_modulus
)
sim.append(beam_R)

# ------------------------------------------------------------
# Create 10 ribs between beams
# ------------------------------------------------------------
num_ribs = 10
ribs = []

for i in range(num_ribs):
    s = (i + 1) / (num_ribs + 1)

    pL = start_L + s * (main_beam_left[1] - main_beam_left[0])
    pR = start_R + s * (main_beam_right[1] - main_beam_right[0])

    rib_start = pL
    rib_end = pR
    rib_dir = rib_end - rib_start
    rib_len = np.linalg.norm(rib_dir)
    rib_dir = rib_dir / rib_len

    rib = ea.CosseratRod.straight_rod(
        n_elem_rib, rib_start, rib_dir, normal_vec, rib_len,
        radius, density, youngs_modulus=E, shear_modulus=shear_modulus
    )
    ribs.append(rib)
    sim.append(rib)

# ------------------------------------------------------------
# Visualization BEFORE simulation
# ------------------------------------------------------------
def plot_structure_before():
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    # main beams
    ax.plot(
        [main_beam_left[0][0], main_beam_left[1][0]],
        [main_beam_left[0][1], main_beam_left[1][1]],
        [main_beam_left[0][2], main_beam_left[1][2]],
        'b-', label="Left beam"
    )
    ax.plot(
        [main_beam_right[0][0], main_beam_right[1][0]],
        [main_beam_right[0][1], main_beam_right[1][1]],
        [main_beam_right[0][2], main_beam_right[1][2]],
        'g-', label="Right beam"
    )

    # ribs
    for i in range(num_ribs):
        s = (i + 1) / (num_ribs + 1)
        pL = start_L + s * (main_beam_left[1] - main_beam_left[0])
        pR = start_R + s * (main_beam_right[1] - main_beam_right[0])
        ax.plot([pL[0], pR[0]], [pL[1], pR[1]], [pL[2], pR[2]], 'r-')

    ax.set_title("Geometry BEFORE simulation")
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_zlabel("Z")
    ax.legend()
    plt.show()

plot_structure_before()

# ------------------------------------------------------------
# Boundary conditions
# ------------------------------------------------------------
sim.constrain(beam_L).using(
    ea.OneEndFixedBC, constrained_position_idx=(0,), constrained_director_idx=(0,)
)

# ------------------------------------------------------------
# Connect ribs to beams
# ------------------------------------------------------------
for i, rib in enumerate(ribs):
    idx_beam = int((i + 1) / (num_ribs + 1) * n_elem_beam)

    sim.connect(
        first_rod=beam_L,
        second_rod=rib,
        first_connect_idx=idx_beam,
        second_connect_idx=0
    ).using(ea.FixedJoint, k=1e5, nu=0.0, kt=1e1, nut=0.0)

    sim.connect(
        first_rod=rib,
        second_rod=beam_R,
        first_connect_idx=-1,
        second_connect_idx=idx_beam
    ).using(ea.FixedJoint, k=1e5, nu=0.0, kt=1e1, nut=0.0)

# ------------------------------------------------------------
# Add force to right beam end
# ------------------------------------------------------------
sim.add_forcing_to(beam_R).using(
    ea.EndpointForcesSinusoidal,
    start_force_mag=0,
    end_force_mag=5e-2,
    ramp_up_time=0.2,
    tangent_direction=dir_R,
    normal_direction=normal_vec,
)

# ------------------------------------------------------------
# Damping
# ------------------------------------------------------------
dt = 1e-4
damping_constant = 0.2

for rod in [beam_L, beam_R] + ribs:
    sim.dampen(rod).using(
        # ea.LimitDamping,
        damping_constant=damping_constant,
    )

# ------------------------------------------------------------
# Diagnostics
# ------------------------------------------------------------
pp = []
for rod in [beam_L, beam_R] + ribs:
    d = ea.defaultdict(list)
    pp.append(d)
    sim.collect_diagnostics(rod).using(
        ea.MyCallBack, step_skip=1000, callback_params=d
    )

# ------------------------------------------------------------
# Finalize and run
# ------------------------------------------------------------
sim.finalize()
timestepper = ea.PositionVerlet()

final_time = 5.0
total_steps = int(final_time / dt)
ea.integrate(timestepper, sim, final_time, total_steps)

# ------------------------------------------------------------
# Visualization AFTER simulation
# ------------------------------------------------------------
def plot_structure_after():
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    # main beams
    ax.plot(
        beam_L.position_collection[0, :],
        beam_L.position_collection[1, :],
        beam_L.position_collection[2, :],
        'b-', label="Left beam"
    )
    ax.plot(
        beam_R.position_collection[0, :],
        beam_R.position_collection[1, :],
        beam_R.position_collection[2, :],
        'g-', label="Right beam"
    )

    # ribs
    for rib in ribs:
        ax.plot(
            rib.position_collection[0, :],
            rib.position_collection[1, :],
            rib.position_collection[2, :],
            'r-'
        )

    ax.set_title("Geometry AFTER simulation")
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_zlabel("Z")
    ax.legend()
    plt.show()

plot_structure_after()
