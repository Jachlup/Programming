__doc__ = """Hinge joint example, for detailed explanation refer to Zhang et. al. Nature Comm.  methods section."""

import numpy as np
import elastica as ea
from temp_elastica.examples.JointCases.joint_cases_postprocessing import (
    plot_position,
    plot_video,
    plot_video_xy,
    plot_video_xz,
)


class HingeJointSimulator(
    ea.BaseSystemCollection,
    ea.Constraints,
    ea.Connections,
    ea.Forcing,
    ea.Damping,
    ea.CallBacks,
):
    pass


hinge_joint_sim = HingeJointSimulator()

# setting up test params
n_elem = 10
direction = np.array([0.0, 1.0, 0.0])
normal = np.array([0.0, 0.0, 1.0])
roll_direction = np.cross(direction, normal)
base_length = 0.1
base_radius = 0.007
base_area = np.pi * base_radius**2
density = 1750
E = 3e7
poisson_ratio = 0.5
shear_modulus = E / (poisson_ratio + 1.0)

start_rod_1 = np.zeros((3,))
start_rod_2 = np.array([0.0, 0.1, 0.0])

# Create rod 1
rod1 = ea.CosseratRod.straight_rod(
    n_elem,
    start_rod_1,
    direction,
    normal,
    base_length,
    base_radius,
    density,
    youngs_modulus=E,
    shear_modulus=shear_modulus,
)
hinge_joint_sim.append(rod1)
# Create rod 2

direction = np.array([0.03, 0.0045, 0.0])


rod2 = ea.CosseratRod.straight_rod(
    n_elem,
    start_rod_2,
    direction,
    normal,
    base_length,
    base_radius,
    density,
    youngs_modulus=E,
    shear_modulus=shear_modulus,
)
hinge_joint_sim.append(rod2)

# Apply boundary conditions to rod1.
hinge_joint_sim.constrain(rod1).using(
    ea.OneEndFixedBC, constrained_position_idx=(0,), constrained_director_idx=(0,)
)
hinge_joint_sim.constrain(rod2).using(
    ea.OneEndFixedBC, constrained_position_idx=(-1,), constrained_director_idx=(0,)
)


# Connect rod 1 and rod 2
hinge_joint_sim.connect(
    first_rod=rod1, second_rod=rod2, first_connect_idx=-1, second_connect_idx=0
).using(
    ea.HingeJoint, k=1e5, nu=0, kt=1e1, normal_direction=roll_direction
)  # 1e-2

# Add forces to rod2
start_force = np.array([0.0, 0.0, 0.0], dtype=np.float64)
end_force   = np.array([0.0, 0, 0.0], dtype=np.float64)
ramp_up_time = 0.2

hinge_joint_sim.add_forcing_to(rod2).using(
    ea.EndpointForces,
    start_force,
    end_force,
    ramp_up_time
)


# add damping
damping_constant = 0
dt = 5e-5
hinge_joint_sim.dampen(rod1).using(
    ea.AnalyticalLinearDamper,
    damping_constant=damping_constant,
    time_step=dt,
)
hinge_joint_sim.dampen(rod2).using(
    ea.AnalyticalLinearDamper,
    damping_constant=damping_constant,
    time_step=dt,
)

pp_list_rod1 = ea.defaultdict(list)
pp_list_rod2 = ea.defaultdict(list)

hinge_joint_sim.collect_diagnostics(rod1).using(
    ea.MyCallBack, step_skip=1000, callback_params=pp_list_rod1
)
hinge_joint_sim.collect_diagnostics(rod2).using(
    ea.MyCallBack, step_skip=1000, callback_params=pp_list_rod2
)

hinge_joint_sim.finalize()
timestepper = ea.PositionVerlet()
# timestepper = PEFRL()

final_time = 1
dl = base_length / n_elem
total_steps = int(final_time / dt)
print("Total steps", total_steps)
ea.integrate(timestepper, hinge_joint_sim, final_time, total_steps)



# PLOT_FIGURE = True
SAVE_FIGURE = True
PLOT_VIDEO = True

# plotting results
# if PLOT_FIGURE:
#     filename = "Test4.png"
#     plot_position(pp_list_rod1, pp_list_rod2, filename, SAVE_FIGURE)

if PLOT_VIDEO:
    filename = "Test4.mp4"
    # plot_video(pp_list_rod1, pp_list_rod2, video_name=filename, margin=0.2, fps=400)
    plot_video_xy(
        pp_list_rod1, pp_list_rod2, video_name=filename + "_xy.mp4", margin=0.2, fps=100
    )
    # plot_video_xz(
    #     pp_list_rod1, pp_list_rod2, video_name=filename + "_xz.mp4", margin=0.2, fps=100
    # )
