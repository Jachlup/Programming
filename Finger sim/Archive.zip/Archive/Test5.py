__doc__ = """Hinge joint example, for detailed explanation refer to Zhang et. al. Nature Comm.  methods section."""

import numpy as np
import elastica as ea
from pathlib import Path
from matplotlib import pyplot as plt
from Joint_postprocessing import (
    plot_position,
    plot_video_three_rods,
    plot_video_xy_three_rods,
    plot_video_xz,
)


class HingeJointSimulator(
    ea.BaseSystemCollection,
    ea.Constraints,
    ea.Connections,
    ea.Forcing,
    ea.Damping,
    ea.CallBacks,
):
    pass


class NodeForce(ea.NoForces):
    def __init__(self, force, node_idx: int):
        super().__init__()
        self.force = np.asarray(force, dtype=float)
        self.node_idx = int(node_idx)

    def apply_forces(self, system, time=np.float64(0.0)) -> None:
        system.external_forces[..., self.node_idx] += self.force


def endpoints_to_vector_and_length(node_a, node_b):
    direction_vector = node_b - node_a
    length = np.linalg.norm(direction_vector)
    if length == 0.0:
        raise ValueError("Rod endpoints must be different points.")
    direction = direction_vector / length
    return node_a, direction, length


def select_evenly_spaced_node_indices(node_start: int, node_end: int, count: int):
    available_nodes = np.arange(node_start, node_end + 1, dtype=int)
    if count <= 0:
        return np.array([], dtype=int)
    count = min(int(count), available_nodes.size)
    sampled_positions = np.linspace(0, available_nodes.size - 1, count, dtype=int)
    return available_nodes[sampled_positions]


def save_xy_video_autoscale(
    plot_params_rod1: dict,
    plot_params_rod2: dict,
    plot_params_rod3_all,
    video_name: str,
    fps: int = 20,
    rod3_visual_spacing: float = 0.0015,
):
    import matplotlib.animation as manimation

    time = plot_params_rod1["time"]
    position_of_rod1 = np.array(plot_params_rod1["position"])
    position_of_rod2 = np.array(plot_params_rod2["position"])
    position_of_rod3_all = [np.array(plot_params["position"]) for plot_params in plot_params_rod3_all]

    all_x = [position_of_rod1[..., 0].ravel(), position_of_rod2[..., 0].ravel()]
    all_y = [position_of_rod1[..., 1].ravel(), position_of_rod2[..., 1].ravel()]
    for position_of_rod3 in position_of_rod3_all:
        all_x.append(position_of_rod3[..., 0].ravel())
        all_y.append(position_of_rod3[..., 1].ravel())

    x_min = np.nanmin(np.concatenate(all_x))
    x_max = np.nanmax(np.concatenate(all_x))
    y_min = np.nanmin(np.concatenate(all_y))
    y_max = np.nanmax(np.concatenate(all_y))

    x_span = max(x_max - x_min, 1e-6)
    y_span = max(y_max - y_min, 1e-6)
    margin = 0.1 * max(x_span, y_span)

    print("plot video xy (autoscale)")
    ffmpeg_writer = manimation.writers["ffmpeg"]
    metadata = dict(title="Rod network", artist="Matplotlib", comment="Autoscaled XY video")
    writer = ffmpeg_writer(fps=fps, metadata=metadata)
    fig = plt.figure()

    with writer.saving(fig, video_name, 100):
        for frame_id in range(1, len(time)):
            fig.clf()
            ax = fig.add_subplot(111)
            ax.set_aspect("equal", adjustable="box")

            ax.plot(position_of_rod1[frame_id, 0], position_of_rod1[frame_id, 1], "r-o", linewidth=2, markersize=2)
            ax.plot(position_of_rod2[frame_id, 0], position_of_rod2[frame_id, 1], "b-o", linewidth=2.5, markersize=2)

            center = 0.5 * (len(position_of_rod3_all) - 1)
            for rod_idx, position_of_rod3 in enumerate(position_of_rod3_all):
                x_offset = (rod_idx - center) * rod3_visual_spacing
                ax.plot(
                    position_of_rod3[frame_id, 0] + x_offset,
                    position_of_rod3[frame_id, 1],
                    "g-o",
                    linewidth=2.0,
                    markersize=1.5,
                    alpha=0.9,
                )

            ax.set_xlim([x_min - margin, x_max + margin])
            ax.set_ylim([y_min - margin, y_max + margin])
            writer.grab_frame()


hinge_joint_sim = HingeJointSimulator()

# setting up test params
n_elem = 12
normal = np.array([0.0, 0.0, 1.0])
roll_direction = normal.copy()
base_radius = 0.007
base_area = np.pi * base_radius**2
density = 1750
E = 2e6
poisson_ratio = 0.5
shear_modulus = E / (poisson_ratio + 1.0)
E_rod3 = 2e5
shear_modulus_rod3 = E_rod3 / (poisson_ratio + 1.0)

# Rod3 attachment distribution control
# Choose how many main-beam nodes should be connected to rod3 rods.
# Example: with n_elem=8, valid node indices are 0..8.
# A good "almost every node" choice is n_elem - 1 (all except fixed node 0 and tip node n_elem).
connected_nodes_on_main_beam = 10
main_beam_attach_start = 1
main_beam_attach_end = n_elem - 2
rod2_attach_start = 1
rod2_attach_end = n_elem - 2
min_rod3_length = 0.0

# Stability controls for dense rod3 connections
main_joint_k = 1e4
main_joint_nu = 150.0
rod3_joint_k = 4e2
rod3_joint_nu = 120.0
applied_force = np.array([0.02, 0.0, 0.0])

start_rod_1 = np.array([0.0, 0.0, 0.0])
end_rod_1 = np.array([0.0, 0.1, 0.0])
start_rod_1, direction_rod1, base_length = endpoints_to_vector_and_length(
    start_rod_1, end_rod_1
)

attach_idx_rod1 = n_elem // 2

start_rod_2 = np.array([0.03, 0.0045, 0.0])
end_rod_2 = end_rod_1.copy()
start_rod_2, direction_rod2, base_length_rod2 = endpoints_to_vector_and_length(
    start_rod_2, end_rod_2
)

attach_idx_rod2 = n_elem // 2

main_available_count = max(main_beam_attach_end - main_beam_attach_start + 1, 0)
rod2_available_count = max(rod2_attach_end - rod2_attach_start + 1, 0)
requested_links = int(connected_nodes_on_main_beam)
target_links = min(requested_links, main_available_count, rod2_available_count)

if target_links <= 0:
    raise ValueError(
        "No valid attachment nodes available. Check main/rod2 attachment start/end indices."
    )

attach_idx_rod1_all = select_evenly_spaced_node_indices(
    main_beam_attach_start,
    main_beam_attach_end,
    target_links,
)
attach_idx_rod2_all = select_evenly_spaced_node_indices(
    rod2_attach_start,
    rod2_attach_end,
    target_links,
)

valid_attach_idx_rod1_all = []
valid_attach_idx_rod2_all = []
for attach_idx_rod2_i, attach_idx_rod1_i in zip(attach_idx_rod2_all, attach_idx_rod1_all):
    attach_pos_rod2_i = start_rod_2 + direction_rod2 * (
        base_length_rod2 * int(attach_idx_rod2_i) / n_elem
    )
    attach_pos_rod1_i = start_rod_1 + direction_rod1 * (
        base_length * int(attach_idx_rod1_i) / n_elem
    )
    rod3_length_i = np.linalg.norm(attach_pos_rod1_i - attach_pos_rod2_i)
    if rod3_length_i >= min_rod3_length:
        valid_attach_idx_rod2_all.append(int(attach_idx_rod2_i))
        valid_attach_idx_rod1_all.append(int(attach_idx_rod1_i))

if len(valid_attach_idx_rod1_all) == 0:
    raise ValueError(
        "No valid rod3 links after filtering short beams. Reduce min_rod3_length or change attachment ranges."
    )

num_parallel_rod3 = len(valid_attach_idx_rod1_all)
print(
    f"Requested rod3 links: {requested_links}, feasible links: {target_links}, created rod3 links: {num_parallel_rod3}"
)

# Create rod 1
rod1 = ea.CosseratRod.straight_rod(
    n_elem,
    start_rod_1,
    direction_rod1,
    normal,
    base_length,
    base_radius,
    density,
    youngs_modulus=E,
    shear_modulus=shear_modulus,
)
hinge_joint_sim.append(rod1)
# Create rod 2
normal = np.array([0.0, 0.0, 1.0])
rod2 = ea.CosseratRod.straight_rod(
    n_elem,
    start_rod_2,
    direction_rod2,
    normal,
    base_length_rod2,
    base_radius,
    density,
    youngs_modulus=E,
    shear_modulus=shear_modulus,
)
hinge_joint_sim.append(rod2)

# Create multiple rod3-like rods between distributed rod1/rod2 attachment points
rod3_list = []
for attach_idx_rod2_i, attach_idx_rod1_i in zip(
    valid_attach_idx_rod2_all, valid_attach_idx_rod1_all
):
    attach_pos_rod2_i = start_rod_2 + direction_rod2 * (
        base_length_rod2 * int(attach_idx_rod2_i) / n_elem
    )
    attach_pos_rod1_i = start_rod_1 + direction_rod1 * (
        base_length * int(attach_idx_rod1_i) / n_elem
    )

    start_rod_3_i = attach_pos_rod2_i.copy()
    end_rod_3_i = attach_pos_rod1_i.copy()
    start_rod_3_i, direction_rod3_i, base_length_rod3_i = endpoints_to_vector_and_length(
        start_rod_3_i, end_rod_3_i
    )

    rod3_i = ea.CosseratRod.straight_rod(
        n_elem,
        start_rod_3_i,
        direction_rod3_i,
        normal,
        base_length_rod3_i,
        base_radius,
        density,
        youngs_modulus=E_rod3,
        shear_modulus=shear_modulus_rod3,
    )
    hinge_joint_sim.append(rod3_i)
    rod3_list.append(rod3_i)

# Apply boundary conditions to rod1.
hinge_joint_sim.constrain(rod1).using(
    ea.OneEndFixedBC, constrained_position_idx=(0,), constrained_director_idx=(0,)
)
hinge_joint_sim.constrain(rod2).using(
    ea.GeneralConstraint,
    rod2.position_collection[..., 0].copy(),
    constrained_position_idx=(0,),
    translational_constraint_selector=np.array([True, True, True]),
)

# Connect rod 1 and rod 2
hinge_joint_sim.connect(
    first_rod=rod1, second_rod=rod2, first_connect_idx=-1, second_connect_idx=-1
).using(
    ea.HingeJoint,
    k=main_joint_k,
    nu=main_joint_nu,
    kt=0.0,
    normal_direction=roll_direction,
)  # 1e-2

# Connect rod 2/rod 1 to every rod3-like rod using distributed attachment nodes
for rod3_i, attach_idx_rod2_i, attach_idx_rod1_i in zip(
    rod3_list, valid_attach_idx_rod2_all, valid_attach_idx_rod1_all
):
    hinge_joint_sim.connect(
        first_rod=rod2,
        second_rod=rod3_i,
        first_connect_idx=int(attach_idx_rod2_i),
        second_connect_idx=0,
    ).using(
        ea.HingeJoint,
        k=rod3_joint_k,
        nu=rod3_joint_nu,
        kt=0.0,
        normal_direction=roll_direction,
    )

    hinge_joint_sim.connect(
        first_rod=rod1,
        second_rod=rod3_i,
        first_connect_idx=int(attach_idx_rod1_i),
        second_connect_idx=-1,
    ).using(
        ea.HingeJoint,
        k=rod3_joint_k,
        nu=rod3_joint_nu,
        kt=0.0,
        normal_direction=roll_direction,
    )

# Add forces to rod2
hinge_joint_sim.add_forcing_to(rod2).using(
    NodeForce,
    force=applied_force,
    node_idx=n_elem // 2,
)

# add damping
damping_constant = 5e-2
dt = 1e-5
hinge_joint_sim.dampen(rod1).using(
    ea.AnalyticalLinearDamper,
    damping_constant=damping_constant,
    time_step=dt,
)
hinge_joint_sim.dampen(rod2).using(
    ea.AnalyticalLinearDamper,
    damping_constant=damping_constant,
    time_step=dt,
)
# Note: keep rod3 undamped to avoid numerical issues in dense jointed configurations.

pp_list_rod1 = ea.defaultdict(list)
pp_list_rod2 = ea.defaultdict(list)
pp_list_rod3_all = [ea.defaultdict(list) for _ in range(num_parallel_rod3)]

hinge_joint_sim.collect_diagnostics(rod1).using(
    ea.MyCallBack, step_skip=200, callback_params=pp_list_rod1
)
hinge_joint_sim.collect_diagnostics(rod2).using(
    ea.MyCallBack, step_skip=200, callback_params=pp_list_rod2
)
for rod3_i, pp_list_rod3_i in zip(rod3_list, pp_list_rod3_all):
    hinge_joint_sim.collect_diagnostics(rod3_i).using(
        ea.MyCallBack, step_skip=200, callback_params=pp_list_rod3_i
    )

hinge_joint_sim.finalize()
timestepper = ea.PositionVerlet()
# timestepper = PEFRL()

final_time = 0.1
dl = base_length / n_elem
total_steps = int(final_time / dt)
print("Total steps", total_steps)
ea.integrate(timestepper, hinge_joint_sim, final_time, total_steps)

position_rod1 = np.array(pp_list_rod1["position"])
position_rod2 = np.array(pp_list_rod2["position"])
position_rod3_0 = np.array(pp_list_rod3_all[0]["position"])
print("Recorded rod1 position shape:", position_rod1.shape)
print("Recorded rod2 position shape:", position_rod2.shape)
print("Recorded rod3[0] position shape:", position_rod3_0.shape)

position_rod3_all = [np.array(pp["position"]) for pp in pp_list_rod3_all]
if len(position_rod3_all) > 1:
    mean_separation_from_first = [
        float(np.nanmean(np.linalg.norm(position_rod3_all[i] - position_rod3_all[0], axis=1)))
        for i in range(1, len(position_rod3_all))
    ]
    print("Mean rod3 separation from rod3_1:", mean_separation_from_first)

print(
    "XY bounds:",
    {
        "rod1_x": (float(np.nanmin(position_rod1[:, 0])), float(np.nanmax(position_rod1[:, 0]))),
        "rod1_y": (float(np.nanmin(position_rod1[:, 1])), float(np.nanmax(position_rod1[:, 1]))),
        "rod2_x": (float(np.nanmin(position_rod2[:, 0])), float(np.nanmax(position_rod2[:, 0]))),
        "rod2_y": (float(np.nanmin(position_rod2[:, 1])), float(np.nanmax(position_rod2[:, 1]))),
    },
)


def save_xy_snapshot(plot_params_rod1, plot_params_rod2, plot_params_rod3_all, frame_id, image_name):
    position_of_rod1 = np.array(plot_params_rod1["position"])
    position_of_rod2 = np.array(plot_params_rod2["position"])
    position_of_rod3_all = [np.array(plot_params["position"]) for plot_params in plot_params_rod3_all]

    all_x = [position_of_rod1[..., 0].ravel(), position_of_rod2[..., 0].ravel()]
    all_y = [position_of_rod1[..., 1].ravel(), position_of_rod2[..., 1].ravel()]
    for position_of_rod3 in position_of_rod3_all:
        all_x.append(position_of_rod3[..., 0].ravel())
        all_y.append(position_of_rod3[..., 1].ravel())

    x_min = np.nanmin(np.concatenate(all_x))
    x_max = np.nanmax(np.concatenate(all_x))
    y_min = np.nanmin(np.concatenate(all_y))
    y_max = np.nanmax(np.concatenate(all_y))
    x_span = max(x_max - x_min, 1e-6)
    y_span = max(y_max - y_min, 1e-6)
    margin = 0.1 * max(x_span, y_span)

    fig = plt.figure(figsize=(7, 5))
    ax = fig.add_subplot(111)
    ax.set_aspect("equal", adjustable="box")
    ax.plot(position_of_rod1[frame_id, 0], position_of_rod1[frame_id, 1], "r-o", linewidth=2.5, markersize=2, label="rod1")
    ax.plot(position_of_rod2[frame_id, 0], position_of_rod2[frame_id, 1], "b-o", linewidth=2.5, markersize=2, label="rod2")

    center = 0.5 * (len(position_of_rod3_all) - 1)
    for rod_idx, position_of_rod3 in enumerate(position_of_rod3_all):
        x_offset = (rod_idx - center) * 0.0015
        ax.plot(position_of_rod3[frame_id, 0] + x_offset, position_of_rod3[frame_id, 1], "g-o", linewidth=2.0, markersize=1.5, alpha=0.9)

    ax.set_xlim([x_min - margin, x_max + margin])
    ax.set_ylim([y_min - margin, y_max + margin])
    ax.legend(loc="best")
    fig.savefig(image_name, dpi=180)
    plt.close(fig)

PLOT_FIGURE = False
SAVE_FIGURE = False
PLOT_VIDEO = True

# plotting results
# if PLOT_FIGURE:
#     filename = "hinge_joint_test.png"
#     plot_position(pp_list_rod1, pp_list_rod2, filename, SAVE_FIGURE)

if PLOT_VIDEO:
    output_dir = Path(__file__).resolve().parent
    filename = output_dir / "hinge_joint_test.mp4"
    save_xy_snapshot(
        pp_list_rod1,
        pp_list_rod2,
        pp_list_rod3_all,
        frame_id=0,
        image_name=str(output_dir / "hinge_joint_test_xy_start.png"),
    )
    save_xy_snapshot(
        pp_list_rod1,
        pp_list_rod2,
        pp_list_rod3_all,
        frame_id=-1,
        image_name=str(output_dir / "hinge_joint_test_xy_end.png"),
    )
    # plot_video_three_rods(
    #     pp_list_rod1,
    #     pp_list_rod2,
    #     pp_list_rod3,
    #     video_name=str(filename),
    #     fps=100,
    # )
    save_xy_video_autoscale(
        pp_list_rod1,
        pp_list_rod2,
        pp_list_rod3_all,
        video_name=str(output_dir / "hinge_joint_test_xy.mp4"),
        fps=20,
        rod3_visual_spacing=0.0015,
    )
    save_xy_video_autoscale(
        pp_list_rod1,
        pp_list_rod2,
        pp_list_rod3_all,
        video_name=str(filename),
        fps=20,
        rod3_visual_spacing=0.0015,
    )
    print(f"Saved videos: {output_dir / 'hinge_joint_test_xy.mp4'} and {filename}")
    print(
        f"Saved snapshots: {output_dir / 'hinge_joint_test_xy_start.png'} and {output_dir / 'hinge_joint_test_xy_end.png'}"
    )
    # plot_video_xz(
    #     pp_list_rod1, pp_list_rod2, video_name=filename + "_xz.mp4", margin=0.2, fps=100
    # )
