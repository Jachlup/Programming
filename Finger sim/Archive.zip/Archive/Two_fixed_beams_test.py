import numpy as np
from elastica import *
import matplotlib.pyplot as plt

#System definition
class GripperSimulator(
    BaseSystemCollection, Constraints, Forcing, Damping, CallBacks, Connections
):
    pass
"""
Notes of intern #3
BaseSystemCollection - allows to add beams
Constraints
Forcing - adding forces
Damping - preventing harmonic oscillations
CallBacks - allows to gather data during simulation. 
            Maybe i can delete this for final set of simulations? Cuz i will only gather bitmaps or sth..
            "Dopiero wywołanie collect_diagnostics(...).using(...) faktycznie zużywa zasoby. Lepiej mieć tę "furtkę" otwartą na wypadek, gdybyś nagle potrzebował sprawdzić wykres sił w konkretnym przegubie." ~ Gemini
"""

#Sim parametrs (everything is in metric system (N, Pa, m, s...))

class Beam:
    def __init__(self, simulator, start, end, n_elem): # n elements
        # material parameters
        E = 210000000       # Young's modulus Pa
        rho = 7800          # density g/m^3
        radius = 0.010      # round beams m
        nu = 0.3            # Poisson ratio
        G = E / (nu + 1.0)  # Kirchoff's modulus
        
        # Geometric calculations
        vector = end - start
        length = np.linalg.norm(vector)
        direction = vector / length
        
        # Orientation
        normal = np.array([0.0, 1.0, 0.0])
        if np.allclose(abs(direction), [0, 1, 0]):
            normal = np.array([1.0, 0.0, 0.0])
            
        # Rod creation
        self.rod = CosseratRod.straight_rod(
            n_elem, 
            start, 
            direction, 
            normal, 
            length, 
            radius, 
            rho, 
            youngs_modulus=E, 
            shear_modulus=G
        )
        simulator.append(self.rod)

# Simulation main setup
gripper_sim = GripperSimulator() #Creation of simulation world
final_time = 1
dt = 1e-7
total_steps = int(final_time/dt)


#adding beanz (by coordinate system)
beam_coordinates = [
    (np.array([0.0, 0.0, 0.0]), np.array([1.0, 0.0, 0.0])),  # Beam 1
    (np.array([1.0,0.0,0.0]), np.array([2.0,0.0,0.0]))       # Beam 2
]

#(np.array([0.0, 0.0, 0.0]) - beggining
# , np.array([1.0, 0.0, 0.0])), - ending


# Creation of new beams based on coordinates
beams_list = []
for start, end in beam_coordinates:
    new_beam = Beam(gripper_sim, start, end, n_elem=15)
    beams_list.append(new_beam)


# Setting constraints

gripper_sim.constrain(beams_list[0].rod).using(
    OneEndFixedBC,
    constrained_position_idx=(0,),
    constrained_director_idx=(0,)  #director not orientation!
)

# Setting joints

gripper_sim.connect(
    beams_list[0].rod, 
    beams_list[1].rod
).using(
    FixedJoint,
    k = 1e2,
    nu = 0.1,
    kt = 1e2,
    nut = 0.1,
    #rest_rotation_matrix = np.eye(3)
)



# SETTING FORCES

# Force vectors

start_force = np.array([0.0, 0.0, 0.0])         # [N]
end_force = np.array([0.0, 50.0, 0.0])           # [N]


gripper_sim.add_forcing_to(beams_list[1].rod).using(
    EndpointForces,
    start_force,
    end_force,
    ramp_up_time=0.1
)

for beam in beams_list:
    gripper_sim.dampen(beam.rod).using(
    AnalyticalLinearDamper,
    damping_constant=5.0,
    time_step = dt
)







# Finalize the system (mandatory before simulation or inspection)
gripper_sim.finalize()

# initial_pos = beams_list[0].rod.position_collection.copy()
initial_data = []
for beam_obj in beams_list:
    # Robimy fizyczną kopię współrzędnych
    initial_data.append(beam_obj.rod.position_collection.copy())
    






# final_pos = beams_list[0].rod.position_collection





print(f"Simulation started. Quantity of steps: {total_steps}")

timestepper = PositionVerlet()
integrate(timestepper, gripper_sim, final_time, total_steps)

print(f"Simulation ended.")

plt.figure(figsize=(10, 6))

for i, beam_obj in enumerate(beams_list):
    final_positions = beam_obj.rod.position_collection
    # Plotting X (index 0) and Y (index 1)
    plt.plot(final_positions[0], final_positions[1], 'o-', label=f"Beam {i} Final", lw=2)
    plt.plot(initial_data[i][0], initial_data[i][1], 'k-', label=f"Beam {i} Initial", lw=2)




plt.xlabel('X [m]')
plt.ylabel('Y [m]')
plt.grid(True)

for i, beam_object in enumerate(beams_list):
    final_beam = beam_object.rod.position_collection
    plt.plot(final_beam[0], final_beam[1],'o-', label=f"Beam {i}", lw = 2)



# plt.plot(final_pos[0], final_pos[1], label="before sim")
# plt.plot(initial_pos[0], initial_pos[1], label="after sim")

plt.legend(loc='upper left')

# Important: Keep aspect ratio equal so beams don't look stretched
plt.axis("equal") 

plt.title("Beam deflection")

plt.show()

