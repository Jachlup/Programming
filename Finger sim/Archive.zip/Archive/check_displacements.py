import numpy as np
with open('/home/janek/Desktop/virtual_env/Test7.py') as f:
    code = f.read()

exec(code)

print("ROD 1 POS:")
print(rod1.position_collection)
print("ROD 2 POS:")
print(rod2.position_collection)

for i, r3 in enumerate(rod3_list):
    print(f"ROD 3_{i} POS:")
    print(r3.position_collection)
