import numpy as np

def endpoints_to_vector_and_length(beam_array):
    start = beam_array[0]
    end = beam_array[1]
    direction = end - start
    length = np.linalg.norm(direction)
    direction = direction / length if length > 0 else np.zeros_like(direction)
    return start, direction, length


x = 0.03
y = 0.0045


main_beam_left = [np.array([0, 0, 0]), np.array([0, 0.1, 0])]  # Start and end of left beam
main_beam_right = [np.array([0, 0.1, 0]), np.array([x, y, 0])]  # Start and end of right beam



start, direction, length = endpoints_to_vector_and_length(main_beam_left)

print("Start:", start)
print("Direction:", direction)
print("Length:", length)

start, direction, length = endpoints_to_vector_and_length(main_beam_right)

print("Start:", start)
print("Direction:", direction)
print("Length:", length)