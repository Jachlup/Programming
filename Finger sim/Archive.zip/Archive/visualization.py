import numpy as np
import matplotlib.pyplot as plt

def create_slanted_parallel_ribs(left_start, left_end, right_start, right_end, n_ribs=10):
    # linia 1: od początku lewej belki do końca prawej
    A0 = left_start
    A1 = right_end

    # linia 2: od końca lewej belki do początku prawej
    B0 = left_end
    B1 = right_start

    for t in np.linspace(0, 1, n_ribs):
        # interpolacja punktów początkowych i końcowych
        p_left  = (1 - t) * A0 + t * B0
        p_right = (1 - t) * A1 + t * B1

        # rysowanie żebra
        plt.plot([p_left[0], p_right[0]], [p_left[1], p_right[1]], 'b-', lw=2)


# --- Dane wejściowe ---
x = 0.03
y = 0.0045

main_beam_left  = [np.array([0.0, 0.0]), np.array([0.0, 0.1])]
main_beam_right = [np.array([0.0, 0.1]), np.array([x, y])]

# --- Rysowanie belek głównych ---
plt.plot(
    [main_beam_left[0][0], main_beam_left[1][0]],
    [main_beam_left[0][1], main_beam_left[1][1]],
    'k-', lw=3
)

plt.plot(
    [main_beam_right[0][0], main_beam_right[1][0]],
    [main_beam_right[0][1], main_beam_right[1][1]],
    'k-', lw=3
)

# --- Rysowanie pochylonych, równoległych żeber ---
create_slanted_parallel_ribs(
    main_beam_left[0], main_beam_left[1],
    main_beam_right[0], main_beam_right[1],
    n_ribs=12
)

# --- Ustawienia wykresu ---
plt.title("Visualization of Fin Ray Gripper Beams and Ribs")
plt.xlabel("X [m]")
plt.ylabel("Y [m]")
plt.axis("equal")
plt.grid(True)

plt.show()
